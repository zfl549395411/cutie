### PointCloudNoiseFilter

1. 简介

   该项目为点云噪声过滤函数库，数据需要是雷达原始的上传数据，不能是去零点和重排过的。

2. 项目依赖

	```
    ubuntu 18.04 or ubuntu 20.04
    pcl
    boost 
    opencv 
    版本应与lib对应版本一致
	```
   
3. 接口介绍

   3.1.1 PointCloudNoiseFilter 类构造方式

   ```
    std::unique_ptr<PointCloudNoiseFilter> pcnf = std::make_unique<PointCloudNoiseFilter>()
    pcnf->setCalibrationParam(0.0,0.0,0.824,0.00282785227,-0.0114345308,-0.008901179185171082);
    or 
    std::unique_ptr<PointCloudNoiseFilter> pcnf = std::make_unique<PointCloudNoiseFilter(
    0.0,0.0,0.824,0.00282785227,-0.0114345308,-0.008901179185171082);
   ```

   3.1.2 PointCloudNoiseFilter 类参数设置

   ```
   当前的噪声过滤库中包含两种噪声过滤算法
   1 高反膨胀点过滤算法
   2 兔子点过滤算法
   3 阳关噪声去除算法
   通过设置FilterMode函数配置启用的噪声点过滤算法
   isfilter_hig_intensity_noise_: true //过滤高反噪声点，false关闭
   isfilter_rabbit_noise_:true //过滤兔子点噪声，false关闭
   isfilter_sun_noise_: true // 过滤阳光噪声，false关闭
   fg:关闭高反噪声过滤函数，打开兔子点过滤函数和阳光噪声点过滤函数
   pcnf->setFilterMode(false,true,true);
   ```

   3.2 调用 filter函数

   输入: XYZI点云指针

   输出: std::vector\<std::uint32_t\> label

   ```
   pcl::PointCloud<pcl::PointXYZI>::Ptr raw_point_cloud(new pcl::PointCloud<pcl::PointXYZI>());
   auto label = pcnf->filter(raw_point_cloud);
   ```

   ```
   label定义:
   0 is_valid
   1 high_intensity_noise
   2 rabbit noise 
   3 sun noise
   ```

4. demo 编译样例

	使用方式，可参建main.cpp

	```
	 编译方式：
    mkdir build
    cd build
    cmake .. && make -j4
    样例运行方式：
    编译完成后，./test_main [pcd数据路径] [噪声点保存路径]
    注：pcd数据路径下必须有1.pcd点云信息
	```
5. 注意事项
   + 兔子点噪声消除算法、阳光噪声算法依赖雷达原始的上传数据，不能是去NAN点和重排过的;
   + 激光雷达应水平安装，兔子点去除算法目前没有读取标定参数，激光倾斜的话会导致误检到地面点;
   + 阳光噪去除中距离单位为0.5cm，输入的m单位坐标需要先乘200保证单位一致