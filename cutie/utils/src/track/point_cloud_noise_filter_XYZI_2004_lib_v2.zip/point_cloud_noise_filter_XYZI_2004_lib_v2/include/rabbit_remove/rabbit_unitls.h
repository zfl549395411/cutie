#ifndef RABBIT_UNITLS_H_
#define RABBIT_UNITLS_H_
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <opencv2/opencv.hpp>


using LidarPointCloud = pcl::PointCloud<pcl::PointXYZI>;
constexpr int VIEW_FIELD_HEIGHT = 126;
constexpr int VIEW_FIELD_WIDTH = 125;
constexpr int MEMS_CHANNEL_NUM_BLOCK = 5;
constexpr int M1_POINTS_NUM = VIEW_FIELD_HEIGHT * VIEW_FIELD_WIDTH * MEMS_CHANNEL_NUM_BLOCK;
constexpr int SECTOR_POINTS_NUM = VIEW_FIELD_HEIGHT * VIEW_FIELD_WIDTH;
constexpr double RABBIT_MAX_DIST = 9.0;
constexpr double RABBIT_MIN_DIST = 0.5;
const std::vector<uint8_t> HIGH_INTENSITY_DUAL_THRES_CLOSE = {120u, 100u};
const std::vector<uint8_t> HIGH_INTENSITY_DUAL_THRES_FAR = {200u, 100u};
const std::vector<cv::Point2i> EIGHT_NEIGHBOURS_OFFSET = {
    cv::Point2i(-1, -1),
    cv::Point2i(-1, 0),
    cv::Point2i(-1, 1),
    cv::Point2i(0, -1),
    cv::Point2i(0, 1),
    cv::Point2i(1, -1),
    cv::Point2i(1, 0),
    cv::Point2i(1, 1)
};
const std::vector<cv::Point2i> UPPER_HALF_NEIGHBOURS_OFFSET = {
    cv::Point2i(-1, -1),
    cv::Point2i(-1, 0),
    cv::Point2i(-1, 1),
    cv::Point2i(0, -1),
    cv::Point2i(0, 1)
};

inline std::tuple<int, int, int> line_idx_to_hwc(int line_idx)
{
    int c = line_idx % MEMS_CHANNEL_NUM_BLOCK;
    int hw = std::floor(line_idx / MEMS_CHANNEL_NUM_BLOCK);
    int h = std::floor(hw / VIEW_FIELD_WIDTH);
    int w = hw - h * VIEW_FIELD_WIDTH;

    if (h % 2) {
        w = VIEW_FIELD_WIDTH - 1 - w;
    }

    return {h, w, c};
}

inline int hwc_to_line_idx(const int h, const int w, const int c) 
{
    if (h % 2) {
        return ((h + 1) * VIEW_FIELD_WIDTH - w -1) * MEMS_CHANNEL_NUM_BLOCK + c;
    } else {
        return (h * VIEW_FIELD_WIDTH + w) * MEMS_CHANNEL_NUM_BLOCK + c;
    }
}

inline bool is_hw_valid(const int h, const int w) 
{
    return h >= 0 && h < VIEW_FIELD_HEIGHT && w >= 0 && w < VIEW_FIELD_WIDTH;
}


void find_connected_area_points(const cv::Mat& connected_label, const int n_labels, std::vector<std::vector<cv::Point2i>>& label_points);

template <typename T>
class RangeMaps {
public:
    RangeMaps(int cv_type) {
        mats.resize(MEMS_CHANNEL_NUM_BLOCK);
        for (int c = 0; c < MEMS_CHANNEL_NUM_BLOCK; ++c) {
            mats[c].create(VIEW_FIELD_HEIGHT, VIEW_FIELD_WIDTH, cv_type);
        }
    }

    T get(const int h, const int w, const int c) 
    {
        return *(mats[c].ptr<T>(h, w));
    }

    T get(const std::tuple<int, int, int>& hwc)
    {
        return get(std::get<0>(hwc), std::get<1>(hwc), std::get<2>(hwc));
    }

    T get(const int line_idx) 
    {
        const auto& hwc = line_idx_to_hwc(line_idx);
        return get(hwc);
    }


    void set(const int h, const int w, const int c, const T val)
    {
        *(mats[c].ptr<T>(h, w)) = val;
    }

    void set(const std::tuple<int, int, int>& hwc, const T val) 
    {
        set(std::get<0>(hwc), std::get<1>(hwc), std::get<2>(hwc), val);
    }

    void set(const int line_idx, const T val)
    {
        const auto& hwc = line_idx_to_hwc(line_idx);
        set(hwc, val);
    }

    void clear() 
    {
        for (auto& m : mats) {
            m.setTo(cv::Scalar(0));
        }
    }

    void clear(int channel)
    {
        mats[channel].setTo(cv::Scalar(0));
    }

    cv::Mat& get_map(const int c)
    {
        return mats[c];
    }

    void write_map(const std::string& prefix_str, const bool need_binnary)
    {
        for (int c = 0; c < mats.size(); ++c) {
            if (need_binnary) {
                cv::threshold(mats[c], mats[c], 0, 255, cv::THRESH_BINARY);
            }

            if (0){//mats[c].type() == CV_32FC1) {
                cv::imwrite(prefix_str + std::to_string(c) + ".tiff", mats[c]);
            } else {
                cv::imwrite(prefix_str + std::to_string(c) + ".png", mats[c]);
            }
        }
    }

private:
    std::vector<cv::Mat> mats;
};

#endif // RABBIT_UNITLS_H_
