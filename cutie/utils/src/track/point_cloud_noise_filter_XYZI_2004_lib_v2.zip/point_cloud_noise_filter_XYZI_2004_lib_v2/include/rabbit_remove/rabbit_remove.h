#ifndef RABBIT_REMOVE_H_
#define RABBIT_REMOVE_H_
#include <numeric> 
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include "rabbit_remove/rabbit_unitls.h"


class RabbitRemove {
public:
    explicit RabbitRemove() {}
    ~RabbitRemove() {}

    bool get_rabbit_points_label(LidarPointCloud::Ptr& cloud_ptr, std::vector<uint32_t>& output_labels);

    RabbitRemove(const RabbitRemove&) = delete;
    const RabbitRemove &operator=(const RabbitRemove&) = delete;

private:
    void init();
    void prepare(std::vector<uint32_t>& output_labels);
    void range_preprocess(LidarPointCloud::Ptr& cloud_ptr);
    void search_high_point_areas();
    void search_and_check_sector_rabbit_areas();
    bool search_canndiate_rabbit_areas(const std::vector<cv::Point2i>& high_area_points, const int c_high, const int c_rabbit, cv::Mat& rabbit_mask);
    void check_sector_rabbit_areas(const cv::Rect2i& high_area_rect, const cv::Mat& rabbit_mask, const int c_rabbit);
    void check_in_xyz_space_and_enlarge(std::vector<uint32_t>& output_labels);
    bool is_plane_point(const int idx);

    bool is_inited = false;
    std::vector<int> in_range_idxs_;
    std::vector<int> high_high_idxs_;
    std::vector<int> sector_canndiate_rabbit_idxs_;
    std::vector<uint8_t> sector_canndiate_labels_;
    std::unique_ptr<RangeMaps<uint8_t>> intensity_range_maps_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<float>> dist_range_maps_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<uint8_t>> high_intensity_masks_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<uint8_t>> low_high_intensity_masks_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<uint8_t>> show_rabbit_areas_ptr_ = nullptr;
    cv::Mat single_rabbit_mask_;

    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_xyz_ptr_ = nullptr;
    pcl::KdTreeFLANN<pcl::PointXYZ>::Ptr kdtree_ptr_ = nullptr;
};

#endif // RABBIT_REMOVE_H_
