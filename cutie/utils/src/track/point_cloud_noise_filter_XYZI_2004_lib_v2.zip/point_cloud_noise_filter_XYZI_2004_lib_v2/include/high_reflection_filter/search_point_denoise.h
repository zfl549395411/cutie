/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef HIGH_REFLECTION_DENOISE_SEARCH_POINT_DENOISE_H
#define HIGH_REFLECTION_DENOISE_SEARCH_POINT_DENOISE_H

#include "high_reflection_filter/project_view_msg.h"
#include <vector>
#include <memory>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

namespace robosense {
namespace denoise {

/// @class SearchPointDenoise
class SearchPointDenoise {
public:
    using Ptr = std::shared_ptr<SearchPointDenoise>;
    using UPtr = std::unique_ptr<SearchPointDenoise>;

    /// @brief Constructor and Deconstructor
    SearchPointDenoise(std::string debug_dir, bool debug_mode);
    ~SearchPointDenoise();

    /// @brief Resource clear
    void clear();

    /// @brief Dilate Points Denoise
    std::tuple<bool, std::vector<size_t> > dilatePointsDenoise(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr);

public:
    /// --- All for debug ---
    /// Debug file directory
    bool debug_mode_{true};
    std::string debug_dir_;
    /// use opencv
    cv::Mat search_front_components_mat_;
    /// high intensity obj indices
    std::vector<size_t> intensity_obj_indices_;
    /// mask area points indices
    std::vector<size_t> mask_indices_;
    /// test points indices
    std::vector<size_t> test_indices_;

private:
    /// Points project view options
    rscv::MatOption search_range_option_;
    rscv::MatOption denoise_range_option_;
};

}  /// namespace denoise
}  /// namespace robosense

#endif  /// HIGH_REFLECTION_DENOISE_SEARCH_POINT_DENOISE_H
