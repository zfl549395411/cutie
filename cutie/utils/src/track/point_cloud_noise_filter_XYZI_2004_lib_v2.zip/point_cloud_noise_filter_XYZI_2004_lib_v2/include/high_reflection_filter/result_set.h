
#ifndef RESULT_SET_H
#define RESULT_SET_H

#include <limits>
#include <vector>
#include <memory>
#include <iostream>

/// @class KNN Search
/// @brief Data Distance and Index for NN Problem
/// will be one unit in KNNResultSet
class NNDistIndex {
public:
    NNDistIndex(float distance, size_t index) {
        distance_ = distance;
        index_ = index;
    }

    bool operator < (NNDistIndex const &other) const {
        return distance_ < other.distance_;
    }

    bool operator > (NNDistIndex const &other) const {
        return distance_ > other.distance_;
    }

    float distance_{0.F};    /// distance between NN data
    size_t index_{0U};       /// index of one NN data
};

/// @class KNNResultSet
/// @brief Save knn search results
class KNNResultSet {
public:   
    KNNResultSet(size_t capacity) {
        /// Set capacity, how many nn data we want
        capacity_ = capacity;
        /// Create result list
        dist_index_list_.reserve(capacity_);
        for (size_t i{0U}; i < capacity_; ++i) {
            dist_index_list_.emplace_back(NNDistIndex(worst_dist_, 0U));
        }
    }

    /// @brief Valid result size
    size_t size() {
        return count_;
    }

    /// @brief If get enough valid result, that the number must equal to the capacity we set
    bool full() {
        return count_ == capacity_;
    }

    /// @brief Get the worst distance in result set
    float worstDist() {
        return worst_dist_;
    }

    /// @brief Add new data
    void add_point_dist(float dist, size_t index) {
        ++comparison_counter_;  /// add compare one time
        /// if dist greater than worst_dist_, return
        if (dist > worst_dist_) {
            return;
        }
        /// Add count
        if (count_ < capacity_) {
            ++count_;
        }
        /// sort old distance, ascending order
        size_t pre_i = count_ - 1;
        while (pre_i > 0) {
            if (dist_index_list_[pre_i - 1U].distance_ > dist) {
                dist_index_list_[pre_i] = dist_index_list_[pre_i - 1U];
                --pre_i;
            } else {
                break;
            }
        }
        dist_index_list_[pre_i].distance_ = dist;
        dist_index_list_[pre_i].index_ = index;
        worst_dist_ = dist_index_list_[capacity_ - 1].distance_;
    }

    size_t capacity_{0U};  /// results capacity
    size_t count_{0U};  /// valid result number
    float worst_dist_{std::numeric_limits<float>::max()};  /// the worst distance
    std::vector<NNDistIndex> dist_index_list_;  /// Results Set
    size_t comparison_counter_{0U};  /// compare times   
};

/// @class RadiusNNResultSet
/// @brief Save radiusNN search results
class RadiusNNResultSet {
public:
    RadiusNNResultSet(float radius) {
        radius_ = radius;
        count_ = 0U;
        worst_dist_ = radius_;
        dist_index_list_.reserve(100);
        comparison_counter_ = 0U;
    }

    /// @brief Valid result size
    size_t size() {
        return count_;
    }

    /// @brief If get enough valid result, that the number must equal to the capacity we set
    float worstDist() {
        return worst_dist_;
    }

    /// @brief Add new data
    void add_point_dist(float dist, size_t index) {
        ++comparison_counter_;  /// add compare one time
        /// if dist greater than worst_dist_, return
        if (dist > worst_dist_) {
            return;
        }

        ++count_;
        dist_index_list_.emplace_back(NNDistIndex(dist, index));
    }

    float radius_{0.F};  /// find radius
    size_t count_{0U};  /// valid result number
    float worst_dist_{0.F};  /// the worst distance
    std::vector<NNDistIndex> dist_index_list_;  /// Results Set
    size_t comparison_counter_{0U};
};

#endif
