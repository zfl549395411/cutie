
#ifndef KDTREE_H
#define KDTREE_H

#include "high_reflection_filter/result_set.h"
#include <vector>
#include <memory>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

namespace kdtree {

/// @enum Axis Type
/// @brief Hyper plane split space related axis
enum class AxisType : std::uint8_t {
    X = 1U,
    Y = 2U,
    Z = 3U
};

/// @class Node
class Node {
public:
    using Ptr = std::shared_ptr<Node>;

    Node(AxisType axis, std::vector<size_t> &indices) {
        axis_ = axis;
        indices_.assign(indices.begin(), indices.end());
    }

    Node(AxisType axis) {
        axis_ = axis;
    }

    bool is_leaf() {
        return is_leaf_;
    }

    void addPointIndices(std::vector<size_t> const &indices) {
        indices_.assign(indices.begin(), indices.end());
    }

    /// whether it is a leaf node, it is important
    bool is_leaf_{false};
    /// Hyper Plane parmas
    AxisType axis_{AxisType::X};
    float value_{0};
    /// left, right node ptr
    Node::Ptr left_{nullptr};
    Node::Ptr right_{nullptr};
    /// points raw indices
    std::vector<size_t> indices_;
};

/// @brief Build kdtree with recursive method
bool kdtree_recursive_build(Node::Ptr &root, 
                            pcl::PointCloud<pcl::PointXYZI>::Ptr const &points, 
                            std::vector<size_t> &point_indices, 
                            AxisType axis, 
                            size_t leaf_size,
                            std::int32_t cmd);

/// @brief Get kdtree height
size_t get_tree_height(Node::Ptr const &root);

/// @brief KNN Search
/// @param[out] kdtree root node
/// @param[in] points raw points
/// @param[in] query query point
/// @param[out] result_set the search results set
bool knn_search(Node::Ptr const &root,
                pcl::PointCloud<pcl::PointXYZI>::Ptr const &points,
                pcl::PointXYZI const &query,
                KNNResultSet &result_set);

/// @brief Radius NN Search
/// @param[out] kdtree root node
/// @param[in] points raw points
/// @param[in] query query point
/// @param[out] result_set the search results set
bool radiusnn_search(Node::Ptr const &root,
                pcl::PointCloud<pcl::PointXYZI>::Ptr const &points,
                pcl::PointXYZI const &query,
                RadiusNNResultSet &result_set);

}  /// namespace kdtree

#endif  /// KDTREE_H
