/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef HIGH_REFLECTION_DENOISE_PROJECT_VIEW_MSG_H
#define HIGH_REFLECTION_DENOISE_PROJECT_VIEW_MSG_H

#include <vector>
#include <memory>
#include <cstdint>
/// pcl
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
/// opencv
// #include <opencv2/opencv.hpp>

namespace robosense {
namespace denoise {
namespace rscv {

enum class CloudProjectType : std::uint8_t {
    ProjectNone = 0U,
    ProjectFrontView = 1U,
    ProjectBirdEyeView = 2U
};

struct RectangleShape {
    bool shape_valid{false};
    std::int32_t row_min{0};
    std::int32_t row_max{0};
    std::int32_t col_min{0};
    std::int32_t col_max{0};
    float rect_thick{0.F};
    float rect_len{0.F};
};

struct MatOption {
    CloudProjectType projectType{CloudProjectType::ProjectNone};
    float project_res{0.4F};                    /// resolution
    float project_res_div{2.5F};                /// reciprocal value of resolution
    std::uint8_t project_intensity_high{0U};    /// itensity threshold
    std::uint8_t project_intensity_low{255U};   /// itensity threshold
    float project_origin_x{40.F};               /// column origin start value
    float project_origin_y{20.F};               /// row origin start value
    float project_x_range{80.F};                /// column project range
    float project_y_range{20.F};                /// row project range
    float project_dis_min{1.F};                 /// Min distance, in frontview this is x, In verticalview this is z
    float project_dis_max{180.F};               /// Max distance, in frontview this is x, In verticalview this is z
};

class Mat {
public:
    using Ptr = std::shared_ptr<Mat>;
    using ViewToPtIndice = std::vector<std::vector<size_t> >;
    using ViewToPtIndicePtr = std::shared_ptr<ViewToPtIndice>;

    Mat();
    explicit Mat(MatOption const& option);
    Mat(std::int32_t const rows, std::int32_t const cols);
    ~Mat();

    void assignValue(std::int32_t const rows, std::int32_t const cols, std::uint8_t const value);
    std::uint8_t getViewValue(std::int32_t const row, std::int32_t const col) const;
    void setViewValue(std::int32_t const row, std::int32_t const col, std::uint8_t const value);
    void setViewValue(std::int32_t const start_row, std::int32_t const end_row,
                    std::int32_t const start_col, std::int32_t const end_col,
                    std::uint8_t const value);

    rscv::Mat::Ptr operator & (Mat const &mat) const;
    rscv::Mat::Ptr operator == (std::uint8_t const &value) const;

    Mat::Ptr oneConnectedComponent(std::uint8_t const componnet_idx);
    std::vector<size_t> oneConnectedComponentIndices(Mat const &src,  std::uint8_t const componnet_idx);

    bool genProjectView(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr);
    bool genSubProjectView(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr, std::vector<size_t> const &pt_indices);

    std::int32_t countNonZero();
    std::int32_t countProjectPts(std::int32_t const row, std::int32_t const col) const;
    std::int32_t countProjectPts(Mat const &mask_mat) const;

    std::int32_t matRowSum(std::int32_t const row, std::int32_t const start_col, std::int32_t const end_col) const;
    /// direction 0:left, 1:right
    std::int32_t matRowContinuousSum(std::int32_t const row, std::int32_t const start_col, std::int32_t direction) const;
    std::int32_t matColSum(std::int32_t const col, std::int32_t const start_row, std::int32_t const end_row) const;
    std::int32_t matRows() const;
    std::int32_t matCols() const;
    std::int32_t matSize() const;

    ViewToPtIndicePtr const getViewToPointIndice() const;
    std::vector<std::uint8_t> copyMatDataToVector() const;
    void show() const;

    /// use opencv
    // cv::Mat copyMatToCvMat(bool use_scale = false) const;

private:
    void clear();

private:
    std::int32_t mat_rows_{0};
    std::int32_t mat_cols_{0};
    MatOption option_{};
    std::vector<std::uint8_t> view_;
    ViewToPtIndicePtr view_to_pt_ptr_;
};

rscv::Mat::Ptr dilate(rscv::Mat const &src, std::int32_t const radius);
rscv::Mat::Ptr dilateLine(Mat const &src, std::int32_t const radius, std::string const &cmd);
rscv::Mat::Ptr erode(Mat const &src, std::int32_t const radius);
std::tuple<std::uint8_t, rscv::Mat::Ptr> connectedComponents(rscv::Mat const &src, std::uint8_t const connectivity);
std::tuple<std::int32_t, std::int32_t> findMatMeanCenter(rscv::Mat const &src);
RectangleShape getRectangleShape(rscv::Mat const &src);

// cv::Mat add_cv_mat(cv::Mat const &first_mat, cv::Mat const &second_mat);

}  /// namespace rscv
}  /// namespace denoise
}  /// namespace robosense

#endif  /// HIGH_REFLECTION_DENOISE_PROJECT_VIEW_MSG_H
