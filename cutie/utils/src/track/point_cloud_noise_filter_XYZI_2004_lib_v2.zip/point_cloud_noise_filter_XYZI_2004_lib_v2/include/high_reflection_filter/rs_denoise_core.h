/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef HIGH_REFLECTION_DENOISE_RS_DENOISE_CORE_H
#define HIGH_REFLECTION_DENOISE_RS_DENOISE_CORE_H

/// sys
#include "high_reflection_filter/project_view_msg.h"
#include <vector>
#include <memory>
/// Eigen
#include <Eigen/Dense>
/// pcl
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>

namespace robosense {
namespace denoise {

///////////////////////////////////////////////////////////////// --- 用于模块拆分分割
/// ---------------- common 数据结构
/// @enum TrafficBoardType 交通牌类别
enum class TrafficBoardType : std::uint8_t {
    UNKNOW = 0U,              /// < unknow 未知
    LowSmallBoard = 1U,       /// < low small board 小的路边牌子
    LowSmallMidBoard = 2U,    /// < low samll mid 路中间小牌子-细分
    LowSmallSideBoard = 3U,   /// < low small side 路右边小牌子-细分
    HighBigBoard = 4U         /// < high big board 高处的大牌子
};

/// @struct Mask 3D Area
/// 需要mask的区域, 保存最大最小的两个角点
/// mask区域应该根据道路结构和历史情况进行设置
struct Mask3DArea {
    std::uint8_t type{0U};  /// 0:unknow 1:left 2:right
    /// min corner point
    float xmin{0.F};
    float ymin{0.F};
    float zmin{0.F};
    /// max corner point
    float xmax{0.F};
    float ymax{0.F};
    float zmax{0.F};
};

/// @struct Traffic Board Obj 交通牌属性
/// 时序上交通牌属性
struct TrafficBoardObj {
    std::uint64_t timestamp{0U};
    /// min max value
    float xmin{0.F};
    float xmax{0.F};
    float ymin{0.F};
    float ymax{0.F};
    float zmin{0.F};
    float zmax{0.F};
    /// center value
    float xmean{0.F};
    float ymean{0.F};
    float zmean{0.F};
    /// history
    bool lock{false};
    float his_ymin{200.F};
    float his_ymax{-200.F};
    /// mask area
    std::vector<Mask3DArea> masks;
    /// board height and width
    float height{0.F};
    float width{0.F};
    /// board thickness
    float thickness{0.F};
    /// board type 0:unknow  1:low small  2:high big - need update
    TrafficBoardType board_type{TrafficBoardType::UNKNOW};
    /// board plane norm
    std::vector<float> norm;
    /// confidence - need update
    float confidence{0.F};
    /// Motion model - need update
    float velocity_x{0.F};
    float velocity_y{0.F};
    /// traced board id - need update
    std::int32_t board_id{-1};  /// max is 999
    std::int32_t life_count{0};
    /// 相对其它牌子是否是运动着的 - need update
    bool moving{false};

    /// @brief 更新已有目标交通牌
    /// 这里更新仅针对当前obj
    /// @param[in] new_obj 与当前board匹配的检测到的交通牌
    void update(TrafficBoardObj const &new_obj) {
        /// 运动模型更新策略
        velocity_x = xmean - new_obj.xmean;
        velocity_y = ymean - new_obj.ymean;
        /// min max值更新
        xmin = new_obj.xmin;
        xmax = new_obj.xmax;
        ymin = new_obj.ymin;
        ymax = new_obj.ymax;
        /// 中心点更新
        xmean = new_obj.xmean;
        ymean = new_obj.ymean;
        zmean = new_obj.zmean;
        /// z方向值的更新策略, 因为垂直视场的原因
        /// zmax的更新需要注意
        if (new_obj.zmax < zmax) {
            zmax = 0.9 * zmax + 0.1 * new_obj.zmax;
        } else {
            zmax = new_obj.zmax;
        }
        zmin = new_obj.zmin;
        /// 尺寸更新
        height = new_obj.height;
        width = new_obj.width;
        thickness = new_obj.thickness;
        norm = new_obj.norm;
        // board_type = new_obj.board_type;
        /// 记录历史的ymin和ymax
        if (ymin < his_ymin) {
            his_ymin = ymin;
        }
        if (ymax > his_ymax) {
            his_ymax = ymax;
        }
        /// 分数和声明周期
        life_count = 0;
        if (confidence < 0.000001) {
            confidence = 0.6;
        } else {
            confidence += 0.2;
            confidence = std::min(confidence, 1.F);
        }
    };

    /// @brief Fade 交通牌目标声明周期更新
    bool fade(float vel_x, float vel_y, bool vel_update) {
        bool able_fade{false};
        life_count++;

        /// 如果置信度高则降低置信度
        /// 并在board已经处于通过状态时fade掉
        if (confidence > 0.5) {
            confidence -= 0.05;
            if (xmean > 1.F) {
                able_fade = false;
            } else {
                able_fade = true;
            }
        } else {  ///　如果置信度不高, 则在life_count大于3的时候fade掉
            std::int32_t board_count_max = 3;
            if (TrafficBoardType::HighBigBoard == board_type) {
                board_count_max = 9;
            }
            if (life_count > board_count_max) {
                able_fade = true;
            }
        }

        /// update fade board
        if (vel_update) {
            velocity_x = vel_x;  
            velocity_y = vel_y;
        }
        xmin = xmin - velocity_x;
        xmax = xmax - velocity_x;
        xmean = xmean - velocity_x;

        return able_fade;
    };
};

/// @struct Road Structure 道路结构
struct RoadStructureDescribe {
    bool left_valid{false};   /// 道路左边界是否有效
    bool right_valid{false};  /// 道路右边界是否有效
    float left_edge{0.F};     /// 道路左边界
    float right_edge{0.F};    /// 道路右边界
};

/// @struct Road Exist Car 车辆存在区域
/// 保存最大最小的两个角点
struct RoadExistCar {
    /// min corner point
    float xmin{0.F};
    float ymin{0.F};
    float zmin{0.F};
    /// max corner point
    float xmax{0.F};
    float ymax{0.F};
    float zmax{0.F};
};

/////////////////////////////////////////////////////////////////
/// ---------------- 预测追踪
/// @class TrafficBoardTrace 交通牌追踪模块
/// @brief 
class TrafficBoardTrace {
public:
    using Ptr = std::shared_ptr<TrafficBoardTrace>;
    using UPtr = std::unique_ptr<TrafficBoardTrace>;

    TrafficBoardTrace();
    ~TrafficBoardTrace();

    /// @brief 添加当前帧交通牌
    void addTrafficBoards(std::vector<TrafficBoardObj> const &new_traffic_boards);
    /// @brief 返回追踪处理后的交通牌
    std::vector<TrafficBoardObj> getTrafficBoards();
    
    /// Traced traffic boards
    std::vector<TrafficBoardObj> traffic_boards_;

private:
    void updateTrafficBoards(std::vector<TrafficBoardObj> const &new_traffic_boards, std::vector<std::uint32_t> const &result);
};


/////////////////////////////////////////////////////////////////
/// ---------------- 固定杆Mask区域
/// @class BoardFixedPoleMask 牌子附近固定杆mask区域搜索
/// @brief 找到一个牌子相对中心点, 一定offset的3d区域, 
///        这个区域内是mask区域, 内部的点不可以被识别为噪点
class BoardFixedPoleMask {
public:
    using Ptr = std::shared_ptr<BoardFixedPoleMask>;
    using UPtr = std::unique_ptr<BoardFixedPoleMask>;

    BoardFixedPoleMask();
    ~BoardFixedPoleMask();

    void addMaskAreaToBoard(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                    std::vector<TrafficBoardObj> &traffic_boards,
                    RoadStructureDescribe const &road_structure);
};


/////////////////////////////////////////////////////////////////
/// ---------------- 交通牌分布分析模块
/// @class TrafficSignsDistributeModule 分析多个交通牌的分布
/// @brief 分析交通牌在街道上分布结构, 按照常理, 对交通牌进行细分类
///        细分的交通牌以及结构信息有助于排除车辆误删以及固定杆mask区域的寻找
class TrafficSignsDistributeModule {
public:
    using Ptr = std::shared_ptr<TrafficSignsDistributeModule>;
    using UPtr = std::unique_ptr<TrafficSignsDistributeModule>;

    TrafficSignsDistributeModule();
    ~TrafficSignsDistributeModule();

    /// @brief 分析交通牌在街道上分布结构
    /// @param[in] msg_ptr 点云
    /// @param[out] traffic_boards 追踪后的交通牌
    void analysisTrafficSigns(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                            std::vector<TrafficBoardObj> &traffic_boards);
    
    /// @brief Get Structure 获取道路结构
    /// @return 道路结构
    RoadStructureDescribe getRoadStructure();

private:
    float k_lane_width_{3.75F};  /// 单车道宽度
    float k_vehicle_mid_{0.F};   /// 可以参考车体中心即y的0点来区分左右
    RoadStructureDescribe road_structure_;  /// 道路结构
};


/////////////////////////////////////////////////////////////////
/// ---------------- 寻找噪点
/// @class TrafficBoardFindNoise 在交通牌附近找到噪点
/// @brief 这里使用的是追踪后的交通牌
class TrafficBoardFindNoise {
public:
    using Ptr = std::shared_ptr<TrafficBoardFindNoise>;
    using UPtr = std::unique_ptr<TrafficBoardFindNoise>;

    TrafficBoardFindNoise();
    ~TrafficBoardFindNoise();

    void findNoisyPoints(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr, 
                        std::vector<TrafficBoardObj> const &traffic_boards,
                        std::vector<RoadExistCar> &road_cars_exist);
    std::vector<std::uint32_t> getNoisyPointsIndices();

private:
    std::vector<std::uint32_t> findOnLowSmallBoard(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                                                TrafficBoardObj const& board,
                                                std::vector<RoadExistCar> &road_cars_exist);
    std::vector<std::uint32_t> findOnHighBigBoard(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                                                TrafficBoardObj const& board);
    std::vector<std::uint32_t> findOnHighBigFadeBoard(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                                                TrafficBoardObj const& board);
    bool findVehicle(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                    TrafficBoardObj const& board, std::int32_t cmd,
                    std::vector<RoadExistCar> &road_cars_exist);

    bool pointInBoard(pcl::PointXYZI const& point, TrafficBoardObj const& board);

    std::vector<std::uint32_t> noise_indices_;
};


/////////////////////////////////////////////////////////////////
/// ----------------- 业务层
/// @class PointCloudDenoiseV2 第二版降噪模块
/// @brief
class PointCloudDenoiseV2 {
public:
    /// 智能指针
    using Ptr = std::shared_ptr<PointCloudDenoiseV2>;
    using UPtr = std::unique_ptr<PointCloudDenoiseV2>;

    /// @brief 构造函数
    PointCloudDenoiseV2(std::string debug_dir, bool debug_mode);
    /// @brief 析构函数
    ~PointCloudDenoiseV2();
    /// @brief 清理资源
    void clear();
    /// @brief 降噪
    /// @param[in] msg_ptr 输入当前帧点云
    /// @return <是否成功, 噪点索引>
    std::tuple<bool, std::vector<std::uint32_t> > dilatePointsDenoise(pcl::PointCloud<pcl::PointXYZI>::Ptr const &msg_ptr,
                                                                      std::vector<std::uint32_t> &label);

public:
    bool debug_mode_{false};  /// 仿真Debug使能
    std::string debug_dir_;   /// 仿真Debug file directory

    /// Debug display pts indices in rviz
    std::vector<size_t> intensity_area_indices_;
    std::vector<size_t> intensity_obj_small_indices_;
    std::vector<size_t> intensity_obj_big_indices_;

    /// 存在的车辆
    std::vector<RoadExistCar> car_exists_;

    /// 用于外部调试 - rviz显示
    std::vector<Mask3DArea> getMask3DCubes();         /// 获取交通牌的mask区域
    RoadStructureDescribe getRoadStructure();         /// 获取道路结构分析信息
    std::vector<TrafficBoardObj> getTrafficBoards();  /// 获取交通牌

private:
    TrafficBoardTrace::Ptr trace_oc_ptr_;                /// 交通牌追踪oc
    TrafficSignsDistributeModule::Ptr analysis_oc_ptr_;  /// 道路结构分析oc
    rscv::MatOption search_range_option_;  /// 前视图投影配置
};

}  /// namespace denoise
}  /// namespace robosense

#endif  /// HIGH_REFLECTION_DENOISE_RS_DENOISE_CORE_H
