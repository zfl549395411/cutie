/******************************************************************************
 * Copyright 2017 RoboSense All rights reserved.
 * Suteng Innovation Technology Co., Ltd. www.robosense.ai

 * This software is provided to you directly by RoboSense and might
 * only be used to access RoboSense LiDAR. Any compilation,
 * modification, exploration, reproduction and redistribution are
 * restricted without RoboSense's prior consent.

 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL ROBOSENSE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *****************************************************************************/

#ifndef RHUNGARIAN_PROCESS_H
#define RHUNGARIAN_PROCESS_H

#include <deque>
#include <vector>
#include <memory>
#include <cassert>
#include <algorithm>

namespace robosense {
namespace denoise {

struct WeightedBipartiteEdge {
    std::uint32_t left;
    std::uint32_t right;
    float cost;

    WeightedBipartiteEdge() : left(), right(), cost() {}
    WeightedBipartiteEdge(std::uint32_t left, std::uint32_t right, float cost) : left(left), right(right), cost(cost) {}
};

struct LeftEdge {
    std::uint32_t right;
    float cost;

    LeftEdge() : right(), cost() {}
    LeftEdge(std::uint32_t right, float cost) : right(right), cost(cost) {}
    
    bool operator<(LeftEdge const &otherEdge) const {
        return right < otherEdge.right || (right == otherEdge.right && cost < otherEdge.cost);
    }
};

/// @class HungarianGraphProcess
class HungarianGraphProcess {
public:
    /// @brief hungarian minimum-weight perfect matching on a weighted bipartite graph
    /// @param n number of nodes on each side
    std::vector<uint32_t> hungarianMinimumWeightPerfectMatching(std::uint32_t n,
        std::vector<WeightedBipartiteEdge> const &allEdges);

private:
    const std::uint32_t unmatched = std::numeric_limits<std::uint32_t>::max();
};

}  /// namespace denoise
}  /// namespace robosense

#endif  /// RHUNGARIAN_PROCESS_H
