#ifndef SUN_NOISE_FILETER_H_
#define SUN_NOISE_FILETER_H_
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <vector>
#include <string>
#include <algorithm>
#include<cmath>
#include<sys/time.h>
// use range map
#include"rabbit_remove/rabbit_unitls.h"



class SunNoiseFilter
{
private:
    bool debuge_mode_ = true;
    int ViewFiled_Height      = 126;
    int ViewFiled_Wide	      = 125;
    float UPPER_DISTANCE_THRESHOLD = 2200;     //经后处理后的最大阳光噪点距离：11m  -> 1m 宽度用于查找
    float LOWER_DISTANCE_THRESHOLD = 400;    //经后处理后的最小阳光噪点距离：2m  0.5 cm

    std::string debug_dir_ = "/home/sti/zfl/point_cloud_noise_filter/result";
    std::unique_ptr<RangeMaps<float>> dist_range_maps_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<float>> x_range_maps_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<float>> y_range_maps_ptr_ = nullptr;
    std::unique_ptr<RangeMaps<float>> z_range_maps_ptr_ = nullptr;
    void prepare(LidarPointCloud::Ptr &cloud_ptr);
    void filter(std::vector<uint32_t> &output_labels);

public:
    SunNoiseFilter(){
        dist_range_maps_ptr_  = std::make_unique<RangeMaps<float>>(CV_32FC1);
        x_range_maps_ptr_  = std::make_unique<RangeMaps<float>>(CV_32FC1);
        y_range_maps_ptr_  = std::make_unique<RangeMaps<float>>(CV_32FC1);
        z_range_maps_ptr_  = std::make_unique<RangeMaps<float>>(CV_32FC1);
    }
    void get_sun_noise_label(LidarPointCloud::Ptr &cloud_ptr, std::vector<uint32_t> &output_labels);
};
#endif