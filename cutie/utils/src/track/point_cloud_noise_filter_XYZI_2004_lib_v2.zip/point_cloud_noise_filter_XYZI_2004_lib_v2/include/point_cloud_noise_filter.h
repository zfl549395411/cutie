#ifndef POINT_CLOUD_NOISE_FILTER_H
#define POINT_CLOUD_NOISE_FILTER_H
#include <iostream>
#include "high_reflection_filter/rs_denoise_core.h"
#include "rabbit_remove/rabbit_remove.h"
#include <pcl/common/transforms.h>
#include"sun_noise_filter/sun_noise_filter.h"
class PointCloudNoiseFilter{
private:
    robosense::denoise::PointCloudDenoiseV2::UPtr filter_oc_ptr;
    std::unique_ptr<RabbitRemove> filter_rabbit_ptr;
    std::unique_ptr<SunNoiseFilter> filter_sun_noise_ptr;
    /// Debug params
    bool debug_mode{false};
    std::string debug_dir{""};
    /// External calibration params
    float roll{0.F};
    float pitch{0.F};
    float yaw{0.F};
    float x{0.F};
    float y{0.F};
    float z{0.F};
    int filter_mode{0};
public:
    PointCloudNoiseFilter();
    PointCloudNoiseFilter(float x_, float y_, float z_, float roll_,float pitch_,float yaw_);
    ~PointCloudNoiseFilter();
    void setCalibrationParam(float x_,float y_,float z_,float roll_,float pitch_,float yaw_);
    void setFilterMode(bool isfilter_hig_intensity_noise, bool isfilter_rabbit_noise, bool isfilter_sun_noise);
    std::vector<size_t> getHigIntenArea();
    /// trans lidar coordinate to car coordinate
    pcl::PointCloud<pcl::PointXYZI>::Ptr transSensorToCar(pcl::PointCloud<pcl::PointXYZI>::Ptr raw_cloud_ptr_);
    pcl::PointCloud<pcl::PointXYZI>::Ptr transCarToSensor(pcl::PointCloud<pcl::PointXYZI>::Ptr car_cloud_ptr_);
    /// filter function
    std::vector<std::uint32_t> filter(pcl::PointCloud<pcl::PointXYZI>::Ptr raw_cloud_ptr_);
    
};
#endif