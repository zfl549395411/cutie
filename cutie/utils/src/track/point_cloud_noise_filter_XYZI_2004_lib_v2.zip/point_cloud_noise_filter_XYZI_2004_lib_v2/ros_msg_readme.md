### PointCloudNoiseFilter

1. 简介

   该项目为点云噪声过滤函数库，数据需要是雷达原始的上传数据，不能是去零点和重排过的。

2. 项目依赖

  ```
   ubuntu 18.04 or ubuntu 20.04
   pcl
   boost 
   opencv 
   版本应与lib对应版本一致
  ```
  

3. 接口介绍

   3.1.1 PointCloudNoiseFilter 类构造方式

   ```
    std::unique_ptr<PointCloudNoiseFilter> pcnf = std::make_unique<PointCloudNoiseFilter>()
    pcnf->setCalibrationParam(0.0,0.0,0.824,0.00282785227,-0.0114345308,-0.008901179185171082);
    or 
    std::unique_ptr<PointCloudNoiseFilter> pcnf = std::make_unique<PointCloudNoiseFilter(
    0.0,0.0,0.824,0.00282785227,-0.0114345308,-0.008901179185171082);
   ```

   3.1.2 PointCloudNoiseFilter 类参数设置

   ```
   当前的噪声过滤库中包含两种噪声过滤算法
   1 高反膨胀点过滤算法
   2 兔子点过滤算法
   3 阳光噪声去除算法
   通过设置FilterMode函数配置启用的噪声点过滤算法
   isfilter_hig_intensity_noise_: true //过滤高反噪声点，false关闭
   isfilter_rabbit_noise_:true //过滤兔子点噪声，false关闭
   isfilter_sun_noise_: true // 过滤阳光噪声，false关闭
   fg:关闭高反噪声过滤函数，打开兔子点过滤函数和阳光噪声点过滤函数
   pcnf->setFilterMode(false,true,true);
   ```

   

   3.2 调用 filter函数

   输入: XYZI点云指针

   输出: std::vector\<std::uint32_t\> label

   ```
   pcl::PointCloud<pcl::PointXYZI>::Ptr raw_point_cloud(new pcl::PointCloud<pcl::PointXYZI>());
   auto label = pcnf->filter(raw_point_cloud);
   ```

   ```
   label定义:
   0 is_valid
   1 high_intensity_noise
   2 rabbit noise 
   3 sun noise
   ```

4. ros_msg使用方式 

  4.1 编译方式

  ```
   mkdir build
   cd build
   cmake .. && make -j4
  ```

4.2 运行方式

​     4.2.1 配置标定参数

​     filter_noise_node.launch中可配置标定参数，点云topic

```
<launch>
    <arg name="roll" default="0.00282785227" /> #标定参数
    <arg name="pitch" default="-0.0114345308" />
    <arg name="yaw" default="-0.008901179185171082" />
    <arg name="x" default="0.0" />
    <arg name="y" default="0.0" />
    <arg name="z" default="0.824" />
    <arg name="isfilter_hig_intensity_noise" default="true" />
    <arg name="isfilter_rabbit_noise" default="true" />
    <arg name="isfilter_sun_noise" default="true" />
    <node pkg="filter_noise" type="test_filter" name="test_filter" output="screen">
        <remap from="/raw_points_cloud" to="/rslidar_points" /> #点云topic
        <param name="roll" value="$(arg roll)" />
        <param name="pitch" value="$(arg pitch)" />
        <param name="yaw" value="$(arg yaw)" />
        <param name="x" value="$(arg x)" />
        <param name="y" value="$(arg y)" />
        <param name="z" value="$(arg z)" />
        <param name="isfilter_hig_intensity_noise" value="$(arg isfilter_hig_intensity_noise)" />
        <param name="isfilter_rabbit_noise" value="$(arg isfilter_rabbit_noise)" />
        <param name="isfilter_sun_noise" value="$(arg isfilter_sun_noise)" />
    </node> 
</launch>

```

​     4.2.2 编译完成点云噪声过滤项目后，在build文件夹下

       source ./devel/setup.zsh (如果是 bash: source ./devel/setup.bash)
       roslaunch  filter_noise filter_noise_node.launch

<img src="./doc/point_filter.png" alt="point_filter" style="zoom:60%;" />

4.2.3运行驱动rslidar_sdk

```
mkdir build
cd build
cmake .. && make -j4
source ./devel/setup.zsh
./devel/lib/rslidar_sdk/rslidar_sdk_node
```

![lidar](./doc/lidar.png)

4.2.4 播包

```
rosbag play *.bag
```

![bag](./doc/bag.png)

4.2.5 开启rviz,进行可视化

```
rviz
topic含义
vehicle_point_cloud，车体坐标系下的点云，未过滤
hig_inten_noise_points_cloud 高反膨胀噪声点
rabbit_noise_points_cloud 兔子噪声点
sun_noise_points_cloud 阳光噪声点
isvalid_points_cloud 过滤后的点云
根据需要选择对应的topic即可
下图选择了有效点和高反膨胀噪声点
为了能够有效的区分有效点和噪声点，可以设置Color Transformer 进行对比
噪声点设置为FlatColor 
正常点云设置为 intensity
```

![rviz](./doc/rviz.png)