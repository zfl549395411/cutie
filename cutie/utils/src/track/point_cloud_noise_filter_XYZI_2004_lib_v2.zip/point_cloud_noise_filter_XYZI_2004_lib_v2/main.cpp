#include <iostream>
#include <pcl/io/pcd_io.h>
#include "point_cloud_noise_filter.h"
void savePCD(std::string save_path_,
            pcl::PointCloud<pcl::PointXYZI>::Ptr in_cloud_ptr_){
    //保存pcd
    if (!in_cloud_ptr_){
        std::cout << "Point cloud pointer is not initialized " << save_path_ << std::endl;
        return;
    }
    if (in_cloud_ptr_->points.size() <= 0){
        std::cout << "Point cloud size is 0 " << save_path_ << std::endl;
        return;
    }
    if (pcl::io::savePCDFileBinary(save_path_,
                                   *in_cloud_ptr_) != 0){
        std::cout << "Unable to save pcd " << save_path_ << " points size " << in_cloud_ptr_->points.size() << std::endl;
    }
    else{
        std::cout << "save pcd to " << save_path_ << std::endl;
    }
}

pcl::PointCloud<pcl::PointXYZI>::Ptr loadPCD(std::string path_){
    //读取pcd
    pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::io::loadPCDFile(path_, *cloud_ptr);
    return cloud_ptr;
}

int main(int argc, char* argv[]) {
    std::string data_path = argv[1];
    std::string save_path = argv[2];
    std::unique_ptr<PointCloudNoiseFilter> pcnf = std::make_unique<PointCloudNoiseFilter>();
    pcnf->setCalibrationParam(0.0,0.0,0.824,0.00282785227,-0.0114345308,-0.008901179185171082);
    pcnf->setFilterMode(true,true,true);
    for(int i=1;i<2;i++){
        auto raw_point_cloud = loadPCD(data_path + "/" + std::to_string(i) + ".pcd");
        pcl::PointCloud<pcl::PointXYZI>::Ptr noise_point_cloud(new pcl::PointCloud<pcl::PointXYZI>());
        auto label = pcnf->filter(raw_point_cloud);
        // 1 save 高反点噪声
        // 2 save rabbit 噪声
        for(long unsigned int i=0;i<label.size();i++){
            // std::cout<<label[i]<<std::endl;
            if(label[i]==1 || label[i]==2 || label[i]==3){
                noise_point_cloud->points.push_back(raw_point_cloud->points[i]);
            }
        }
        savePCD(save_path + "/" +std::to_string(i)+".pcd", noise_point_cloud);
    } 
    return 0;
}