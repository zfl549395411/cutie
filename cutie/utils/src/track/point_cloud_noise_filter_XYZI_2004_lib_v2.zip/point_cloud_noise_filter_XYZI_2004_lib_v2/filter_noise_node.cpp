#include <signal.h>
#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <cv_bridge/cv_bridge.h>
#include <pcl_conversions/pcl_conversions.h>
/// pcl
#include <pcl/common/transforms.h>
#include "point_cloud_noise_filter.h"

void sigHandler(int sig){
    ros::shutdown();
}
class FilterNoise{
private:
  std::string kVehicleBaseCloudTopic_{"/vehicle_point_cloud"};
  std::string kHighIntensityAreaTopic_{"/intensity_area_cloud"}; 
  std::string kHigNoisyPointsCloudTopic_{"/hig_inten_noise_points_cloud"};
  std::string kRabbitNoisyPointsCloudTopic_{"/rabbit_noise_points_cloud"};
  std::string kIsValidPointsCloudTopic_{"/isvalid_points_cloud"};
  std::string kSunNoisePointsCloudTopic_{"/sun_noise_points_cloud"};
  ros::Publisher vehicle_cloud_pub_;
  ros::Publisher intensity_area_pub_;
  ros::Publisher hig_noise_points_cloud_pub_;
  ros::Publisher rabbit_noise_points_cloud_pub_;
  ros::Publisher sun_noise_points_cloud_pub_;
  ros::Publisher isvalid_points_cloud_pub_;
  std::unique_ptr<PointCloudNoiseFilter> pcnf;
  float roll_{0.F};
  float pitch_{0.F};
  float yaw_{0.F};
  float x_{0.F};
  float y_{0.F};
  float z_{0.F};
  bool isfilter_hig_intensity_noise_{true};
  bool isfilter_rabbit_noise_{true};
  bool isfilter_sun_noise_{true};

public:
  FilterNoise(ros::NodeHandle &nh, ros::NodeHandle &private_nh){
    vehicle_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>(kVehicleBaseCloudTopic_, 1);
    intensity_area_pub_ = nh.advertise<sensor_msgs::PointCloud2>(kHighIntensityAreaTopic_, 1);
    hig_noise_points_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>(kHigNoisyPointsCloudTopic_, 1);
    rabbit_noise_points_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>(kRabbitNoisyPointsCloudTopic_, 1);
    sun_noise_points_cloud_pub_= nh.advertise<sensor_msgs::PointCloud2>(kSunNoisePointsCloudTopic_, 1);
    isvalid_points_cloud_pub_ = nh.advertise<sensor_msgs::PointCloud2>(kIsValidPointsCloudTopic_, 1);
    float roll{0.F};
    float pitch{0.F};
    float yaw{0.F};
    float x{0.F};
    float y{0.F};
    float z{0.F};
    bool isfilter_hig_intensity_noise{true};
    bool isfilter_rabbit_noise{true};
    bool isfilter_sun_noise{true};
    if (private_nh.getParam("roll", roll)){
        roll_ = roll;
    }
    if (private_nh.getParam("pitch", pitch)){
        pitch_ = pitch;
    }
    if (private_nh.getParam("yaw", yaw)){
        yaw_ = yaw;
    }
    if (private_nh.getParam("x", x)){
        x_ = x;
    }
    if (private_nh.getParam("y", y)){
        y_ = y;
    }
    if (private_nh.getParam("z", z)){
        z_ = z;
    }
    if (private_nh.getParam("isfilter_hig_intensity_noise", isfilter_hig_intensity_noise)){
        isfilter_hig_intensity_noise_ = isfilter_hig_intensity_noise;
    }
    if (private_nh.getParam("isfilter_rabbit_noise", isfilter_rabbit_noise)){
        isfilter_rabbit_noise_ = isfilter_rabbit_noise;
    }
    if (private_nh.getParam("isfilter_sun_noise", isfilter_sun_noise)){
        isfilter_sun_noise_ = isfilter_sun_noise;
    }
    pcnf = std::make_unique<PointCloudNoiseFilter>();
    pcnf->setCalibrationParam(x_,y_,z_,roll_,pitch_,yaw_);
    pcnf->setFilterMode(isfilter_hig_intensity_noise_,isfilter_rabbit_noise_,isfilter_sun_noise_);
  }
  void pointsCloudCallback(const sensor_msgs::PointCloud2::ConstPtr &msg) {
    pcl::PointCloud<pcl::PointXYZI>::Ptr raw_cloud_ptr(new pcl::PointCloud<pcl::PointXYZI>);
    pcl::fromROSMsg(*msg, *raw_cloud_ptr);
    std::uint64_t msg_stamp_ms{0U};
    msg_stamp_ms = static_cast<std::uint64_t>(msg->header.stamp.toSec() * 1000.0);
    raw_cloud_ptr->header.stamp = msg_stamp_ms;
    raw_cloud_ptr->header.frame_id = msg->header.frame_id;
    raw_cloud_ptr->header.seq = msg->header.seq;
    auto vehicle_base_cloud_ptr = pcnf->transSensorToCar(raw_cloud_ptr);
    auto label = pcnf->filter(raw_cloud_ptr);
    pcl::PointCloud<pcl::PointXYZI>::Ptr hig_inten_noise_pts_ptr(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::PointCloud<pcl::PointXYZI>::Ptr rabbit_noise_pts_ptr(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::PointCloud<pcl::PointXYZI>::Ptr isvalid_pts_ptr(new pcl::PointCloud<pcl::PointXYZI>());
    pcl::PointCloud<pcl::PointXYZI>::Ptr sun_noise_pts_ptr(new pcl::PointCloud<pcl::PointXYZI>());
    for (size_t i{0U}; i < label.size(); ++i)
    {
        // std::cout<<(label[i]==0)<<std::endl;
        if (label[i] == 0)
        {

            isvalid_pts_ptr->points.push_back(raw_cloud_ptr->points[i]);
        }
        else if(label[i]==1){
            hig_inten_noise_pts_ptr->points.push_back(raw_cloud_ptr->points[i]);
        }
        else if(label[i]==2){
            rabbit_noise_pts_ptr->points.push_back(raw_cloud_ptr->points[i]);
        }
        else if(label[i]==3){
            sun_noise_pts_ptr->points.push_back(raw_cloud_ptr->points[i]);
        }
    }
    // std::vector<size_t> const &intensity_area_indices = pcnf->getHigIntenArea();
    // pcl::PointCloud<pcl::PointXYZI>::Ptr intensity_area_ptr(new pcl::PointCloud<pcl::PointXYZI>);
    // for (size_t i{0U}; i < intensity_area_indices.size(); ++i) {
    //     intensity_area_ptr->points.push_back(vehicle_base_cloud_ptr->points[intensity_area_indices[i]]);
    // }
    // std::cout<<intensity_area_ptr->points.size()<<std::endl;
    //publish 发布车体坐标系点云
    sensor_msgs::PointCloud2 ros_vehicle_cloud;
    pcl::toROSMsg(*vehicle_base_cloud_ptr, ros_vehicle_cloud);
    ros_vehicle_cloud.header = msg->header;
    vehicle_cloud_pub_.publish(ros_vehicle_cloud);
    //publish 高反膨胀
    sensor_msgs::PointCloud2 ros_hig_inten_noise_cloud;
    pcl::toROSMsg(*hig_inten_noise_pts_ptr, ros_hig_inten_noise_cloud);
    ros_hig_inten_noise_cloud.header = msg->header;
    hig_noise_points_cloud_pub_.publish(ros_hig_inten_noise_cloud);
    //publish 发布兔子点噪声
    sensor_msgs::PointCloud2 ros_rabbit_noise_cloud;
    pcl::toROSMsg(*rabbit_noise_pts_ptr, ros_rabbit_noise_cloud);
    ros_rabbit_noise_cloud.header = msg->header;
    rabbit_noise_points_cloud_pub_.publish(ros_rabbit_noise_cloud);

    //publish 发布阳光噪声
    sensor_msgs::PointCloud2 ros_sun_noise_cloud;
    pcl::toROSMsg(*sun_noise_pts_ptr, ros_sun_noise_cloud);
    ros_sun_noise_cloud.header = msg->header;
    sun_noise_points_cloud_pub_.publish(ros_sun_noise_cloud);

    //puslish 过滤后的点云
    sensor_msgs::PointCloud2 ros_isvalid_cloud;
    pcl::toROSMsg(*isvalid_pts_ptr, ros_isvalid_cloud);
    ros_isvalid_cloud.header = msg->header;
    isvalid_points_cloud_pub_.publish(ros_isvalid_cloud);
    
  }
};

int main(int argc, char* argv[]) {
    /// ROS Init
    ros::init(argc, argv, "points_denoise_v2");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");

    /// Init Application, subscribe cloud
    FilterNoise filternoise_node(nh, private_nh);
    ros::Subscriber input_cloud_sub;
    std::string kInputCloudTopic{"raw_points_cloud"};
    input_cloud_sub = nh.subscribe(kInputCloudTopic, 1, &FilterNoise::pointsCloudCallback, &filternoise_node);
    signal(SIGINT, sigHandler);

    /// ROS Loop
    ros::spin();

    return 0;
}